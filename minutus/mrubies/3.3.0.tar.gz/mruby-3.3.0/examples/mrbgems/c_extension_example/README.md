# C Extension Example

This is an example gem which implements a C extension.
