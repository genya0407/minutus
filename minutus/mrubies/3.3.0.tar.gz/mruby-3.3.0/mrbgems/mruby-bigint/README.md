# Multi-precision Integer extension for mruby

This extension uses fgmp, which is a public domain implementation of a subset of the GNU gmp library by Mark Henderson <markh@wimsey.bc.ca>.
But it's heavily modified to fit with mruby. You can get the original source code from <https://github.com/deischi/fgmp.git>.
You can read the original README for fgmp in [README-fgmp.md](README-fgmp.md).

If you want to create your own Multi-precision Integer GEM, see [examples/mrbgems/mruby-YOUR-bigint/TODO-HINT.md](../../examples/mrbgems/mruby-YOUR-bigint/TODO-HINT.md).
